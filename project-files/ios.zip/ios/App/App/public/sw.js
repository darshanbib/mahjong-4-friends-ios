/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/// <reference lib="webworker" />
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = (null);
async function openCache() {
    let cacheName = "Mahjong4Friends";
    let cache = await caches.open(cacheName);
    return cache;
}
self.addEventListener("install", function () {
    self.skipWaiting();
});
self.addEventListener("activate", async function () {
    let cache = await openCache();
    //Assuming the user starts a game, all needed assets should (perhaps excluding some sounds) be loaded into cache.
    //Therefore, we aren't worried about caching stuff on serviceworker activation (granted, some requests could be made before cache is loaded, 
    //but in that instance, the second time the site is loaded they'll be cached).  
    let arr = [
        self.registration.scope,
    ];
    arr.forEach((item) => {
        cache.add(item).catch(function (e) { console.log(item, e); });
    });
});
//Network, with fallback to cache.
//TODO: Do we need a timeout? 
self.addEventListener('fetch', async function (event) {
    let url = event.request.url;
    event.respondWith((async () => {
        let cache = await openCache();
        let network;
        try {
            network = await fetch(event.request);
            if (!url.includes("guaranteed")) {
                try {
                    cache.put(url, network.clone());
                }
                catch (e) {
                    console.error(e);
                }
            }
            return network;
        }
        catch (e) {
            let fromCache = await cache.match(url);
            if (fromCache) {
                return fromCache;
            }
        }
    })());
});

/******/ })()
;
//# sourceMappingURL=sw.js.map