const fs = require("fs")
const path = require("path")

const sharp = require("sharp")

const intersectTransparent = require("./intersectTransparent.js")
const getFilesInDirectory = require("./getFilesInDirectory.js")


let bounds = {
	top: 23,
	bottom: 5,
	left: 5,
	right: 5
}

bounds.width = 82 - bounds.left - bounds.right
bounds.height = 128 - bounds.top - bounds.bottom

let images = getFilesInDirectory("/Users/tuckerwillenborg/Documents/GitHub/mahjong/assets/tiles").filter(item => item.endsWith(".png"))

let templateImage = sharp("/Users/tuckerwillenborg/Documents/GitHub/mahjong/assets/tiles/dragon/white.png")
templateImage.extract(bounds)

for (let i in images) {
	let imageSrc = images[i]
	let img = sharp(imageSrc)
	let outputSrc = imageSrc.replace("tiles", "centers/classic")
	if (!fs.existsSync(path.dirname(outputSrc))) {
		fs.mkdirSync(path.dirname(outputSrc), {recursive: true})
	}

	img.extract(bounds)
	intersectTransparent(templateImage, img, bounds).then((outputImage) => {
		outputImage.toFile(outputSrc, (err, info) => {
			console.log(outputSrc, info, err)
		});
	})
}
