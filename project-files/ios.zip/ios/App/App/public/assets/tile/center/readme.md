Open Source Tiles:


Tiles based on works by Cangjie6 (https://commons.wikimedia.org/wiki/User:Cangjie6), CC-BY SA 4.0:

- joker.svg - https://commons.wikimedia.org/wiki/File:MJj1v1-.svg, 
- dragons/fancy-green.svg - https://commons.wikimedia.org/wiki/File:MJd2v3-.svg
- dragons/fancy-white.svg - https://commons.wikimedia.org/wiki/File:MJd3-.svg
- dragons/fancy-red.svg - https://commons.wikimedia.org/wiki/File:MJd1v2-.svg
- animal/cat.svg - https://commons.wikimedia.org/wiki/File:MJat1-.svg
- animal/mouse.svg - https://commons.wikimedia.org/wiki/File:MJat2-.svg
- animal/chicken.svg - https://commons.wikimedia.org/wiki/File:MJat3-.svg
- animal/centipede.svg - https://commons.wikimedia.org/wiki/File:MJat4-.svg
  - centipede.svg contains separate attribution to noun project, https://thenounproject.com/term/centipede/1026152/, which at least today offers it free under an incompatible license. Properly licensing the centipede portion ensures this is safe for me to use, but it's possible that this should be CC-BY NC ND for others. 




Tiles based on works from http://www.martinpersson.org/wordpress/2010/10/free-mahjong-icons/:
- All png based tile image centers.
- These tiles are not open source - All rights reserved. 
