const sharp = require("sharp")

async function intersectTransparent(templateImage, image, bounds) {
	//Takes two sharp images and returns an image with all intersecting pixels made transparent.
	//Input images must have same dimensions.
	//Neither image will be modified.

	let templateBuffer = await templateImage.raw().toBuffer()
	let testBuffer = await image.raw().toBuffer()

	//For every RGBA set that is identical, make the testBuffer item transparent.
	for (let i=0;i<templateBuffer.length;i+=4) {
		let template = templateBuffer.slice(i, i+4)
		let test = testBuffer.slice(i, i+4)

		let matches = template.every((val, index) => {
			return val === test[index]
		})

		// console.log(template, test, matches)

		if (matches) {
			testBuffer[i + 3] = 0x00 //Make the item fully transparent.
		}
	}

	//Output image
	let outputImage = sharp(testBuffer, {
		raw: Object.assign(bounds, {channels: 4})
	})

	return outputImage
}

module.exports = intersectTransparent
